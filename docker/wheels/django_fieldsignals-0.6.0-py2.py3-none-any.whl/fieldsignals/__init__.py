from .signals import pre_save_changed, post_save_changed  # noqa

__version__ = (0, 6, 0)
