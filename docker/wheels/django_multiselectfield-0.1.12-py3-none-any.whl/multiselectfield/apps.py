from django.apps import AppConfig


class MultiSelectFieldConfig(AppConfig):
    name = 'multiselectfield'
    verbose_name = 'Multiselect Field'
