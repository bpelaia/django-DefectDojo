"""Management commands used by django-watson."""

from __future__ import unicode_literals
