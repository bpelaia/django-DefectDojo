__version__ = '1.0a1'

default_app_config = 'auditlog.apps.AuditlogConfig'
