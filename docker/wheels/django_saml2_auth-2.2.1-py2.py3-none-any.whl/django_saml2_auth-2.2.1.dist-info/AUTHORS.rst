This project is written and maintained by Fang Li and
various contributors:


Django Saml2 Auth
-----------------

- Fang Li



Pysaml2
-------

- Roland Hedberg and it's contributors



Contributors
------------

- `DSpeichert <https://github.com/DSpeichert>`_
- `jacobh <https://github.com/jacobh>`_
- `Gene Wood <http://github.com/gene1wood/>`_
- `Terry <https://github.com/tpeng>`_
- `Tim Pierce <https://github.com/qwrrty/>`_ (Adobe Systems)
- `Tonymke <https://github.com/tonymke/>`_
- `pintor <https://github.com/pintor>`_
- `BaconAndEggs <https://github.com/BaconAndEggs>`_
- `Ryan Mahaffey <https://github.com/mahaffey>`_
- `ayr-ton <https://github.com/ayr-ton>`_
_ `kevPo <https://github.com/kevPo>`_
