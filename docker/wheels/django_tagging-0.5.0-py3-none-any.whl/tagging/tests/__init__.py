"""
Tests for tagging.
"""
