"""This module provides cryptographic elements needed by saml2."""
