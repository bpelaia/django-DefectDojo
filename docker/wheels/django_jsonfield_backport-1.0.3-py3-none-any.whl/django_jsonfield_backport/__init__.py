default_app_config = "django_jsonfield_backport.apps.JSONFieldConfig"
